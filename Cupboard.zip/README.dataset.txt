# Cupboard > 2025-05-20 8:36pm
https://universe.roboflow.com/w2-wnewy/cupboard-x0bnt

Provided by a Roboflow user
License: CC BY 4.0

